--[[
应用说明:访问BMP085前，请先调用一次 bsp_InitI2C()函数配置好I2C相关的GPIO.

BMP085 是BOSCH公司生产的的一款高精度、超低能耗的压力传感器。绝对精度最低可以达到0.03hPa。
BMP085 通过I2C总线直接与各种微处理器相连。
压力范围：300 ... 1100hPa（海拔9000米...-500米）
		30kPa ... 110kPa

压强单位：
	inHg 英寸汞柱
	mmHg 毫米汞柱
	mbar 毫巴(=百帕)
	hPa 百帕
	kPa 千帕, 1kPa = 1000Pa
	MPa 兆帕, 1MPa = 1000kPa = 1000000Pa

1百帕=1毫巴=3/4毫米水银柱
在海平面的平均气压 约为1013.25百帕斯卡（760毫米水银柱），这个值也被称为标准大气压

度量衡换算：
	1标准大气压=101 325帕斯卡
	1帕斯卡=9.8692326671601*10-6标准大气压

Doc文件夹下有《全国各地主要城市海拔高度及大气压参考数据.pdf》

城市   海拔高度(m)  气压强度(kPa)
北京     31.2         99.86
天津     3.3          100.48
石家庄   80.5         99.56
太原     777.9        91.92
呼和浩特 1063         88.94
沈阳     41.6         100.07
大连     92.8         99.47
长春     236.8        97.79
哈尔滨   171.7        98.51
上海     4.5          100.53
南京     8.9          100.4
杭州     41.7         100.05
合肥     29.8         100.09
福州     84           99.64
厦门     63.2         99.91
南昌     46.7         99.91
济南     51.6         99.85
武汉     23.3         100.17
郑州     110.4        99.17
长沙     44.9         99.94
广州     6.6          100.45
南宁     72.2         99.6
重庆     259.1        97.32
贵阳     1071.2       88.79
昆明     1891.4       80.8
拉萨     3658.        65.23
西安     396.9        95.92
兰州     1517.2       84.31
成都     505.9        94.77
西宁     2261.2       77.35
银川     1111.5       88.35
乌鲁木齐 917.9        90.67

香港     32           100.56
台北     9            100.53

汕头     1.2          100.55   【最低海拔】广东省
那曲     4507         58.9     【最高海拔】西藏自治区

珠峰高度为海拔 8848米    相当于0.3个大气压 ,即30.39KPa  【该数据存在争议】

【根据气压，温度计算海拔高度，只是大致关系，仅供参考】
H = (RT/gM)*ln(p0/p)
	R为常数8.51
	T为热力学温度（常温下）（摄氏度要转化成热力学温度）
	g为重力加速度10
	M为气体的分子量29
	P0为标准大气压
	P为要求的高度的气压
	这个公式的推导过程较复杂就不推导了，自己应该会转换的。


可以总结出近似的计算公式；
	P=100KPa   H*10kPa/km   H在0,3km之间
	P=70kPa    H*8kPa/km    H在3km,5km之间
	P=54kPa    H*6.5kPa/km   H在5km,7km之间
	P=41kPa    H*5kPa/km   H在7km,10km之间
	P=25kPa    H*3.5kPa/km   H在10km,12km之间

--]]

-------------I2C从机地址 -------------------------------------------

BMP085_SLAVE_ADDRESS = 0xEE	

-------------------------------------------------------------------
Temp = 0    -- 过采样值，可有用户自己设定 
Press  = 0  -- 温度值， 单位 0.1摄氏度
OSS = 0     -- 过采样值，可有用户自己设定 

AC1 = 0     -- 用于保存芯片内部EEPROM的校准参数
AC2 = 0
AC3 = 0
AC4 = 0
AC5 = 0
AC6 = 0
B1 = 0
B2 = 0
MB = 0
MC = 0
MD = 0
-------------------------------------------------------------------

-- 数据转换
function absif(value)
	if (value >32767) then
		value =  value -65536
	end
	return value
end

-- 读取BMP085寄存器数值，连续2字节。用于温度寄存器
-- _ucRegAddr 寄存器地址
-- 返 回 值: 寄存器值
function BMP085_Read2Bytes(_ucRegAddr)

	local ucData1
	local ucData2
	local usRegValue
	local byte0 
	local byte1

	i2c_bus("start")
	i2c_bus("send", BMP085_SLAVE_ADDRESS) -- 发送设备地址+写信号

	i2c_bus("send", _ucRegAddr)

	i2c_bus("start")
	i2c_bus("send", BMP085_SLAVE_ADDRESS|1) -- 发送设备地址+读信号


	str = i2c_bus("recive", 2) -- 读取两个字节数据

	byte0 = tonumber(string.byte(str,1,1))
	byte1 = tonumber(string.byte(str,2,2))

	w = byte0 * 256 + byte1

	i2c_bus("stop")

	return w 
end

-- 读取BMP085寄存器数值，连续3字节  用于读压力寄存器
-- _ucRegAddr 寄存器地址
-- 返 回 值: 寄存器值
function BMP085_Read3Bytes( _ucRegAddr)
	local ucData1
	local ucData2
	local usRegValue
	local byte0 
	local byte1
	local byte2

	i2c_bus("start")
	i2c_bus("send", BMP085_SLAVE_ADDRESS) -- 发送设备地址+写信号

	i2c_bus("send", _ucRegAddr)

	i2c_bus("start")
	i2c_bus("send", BMP085_SLAVE_ADDRESS|1) -- 发送设备地址+读信号

	str = i2c_bus("recive", 3) -- 读取三个字节数据

	byte0 = tonumber(string.byte(str,1,1))
	byte1 = tonumber(string.byte(str,2,2))
	byte2 = tonumber(string.byte(str,3,3))

	w = byte0 * 65536 + byte1 * 256 + byte2

	i2c_bus("stop")

	return w 
end

-- 写寄存器
-- _ucOpecode : 寄存器地址
-- _ucRegData : 寄存器数据
function BMP085_WriteReg(_ucRegAddr,  _ucRegValue)
	i2c_bus("start")
	i2c_bus("send", BMP085_SLAVE_ADDRESS)
	i2c_bus("send", _ucRegAddr)
	i2c_bus("send", _ucRegValue)
	i2c_bus("stop")
end

-- 等待内部转换结束
function BMP085_WaitConvert()
	if(OSS == 0) then
		delayms(6)  -- 4.5ms  7.5ms  13.5ms   25.5ms
	end

	if(OSS == 1) then
		delayms(9)  -- 4.5ms  7.5ms  13.5ms   25.5ms
	end

	if(OSS == 2) then
		delayms(15)  -- 4.5ms  7.5ms  13.5ms   25.5ms
	end

	if(OSS == 3) then
		delayms(27)  -- 4.5ms  7.5ms  13.5ms   25.5ms
	end
end

-- 读取BMP085测量的温度值和压力值。
function BMP085_ReadTempPress()
	local  UT
 	local  X1 
 	local  X2 
 	local  B5
 	local  T
	local  UP
 	local  X3
 	local  B3
 	local  B6
 	local  B7 
 	local  p
	local  B4
	local  s

	-- 流程见 pdf page 12

	-- 读温度原始值
	BMP085_WriteReg(0xF4, 0x2E)
	BMP085_WaitConvert() -- 等待转换结束
	UT = BMP085_Read2Bytes(0xF6)

	-- 读压力原始值
	BMP085_WriteReg(0xF4, 0x34 + OSS*(2^6))
	BMP085_WaitConvert() -- 等待转换结束
	UP = BMP085_Read3Bytes(0xF6) /(2^(8-OSS))

	--计算真实温度（单位 0.1摄氏度）
	X1 = ((UT - AC6) * AC5) /2^15
	X2 = (MC *2^11) / (X1 + MD)
	B5 = X1 + X2	-- 该系数将用于压力的温度补偿计算
	T = (B5 + 8) / 16
	Temp = T        -- 将计算结果保存在全局变量
 
	-- 计算真实压力值（单位 Pa）
	B6 = B5 - 4000
	X1 = (B2 * (B6 * B6) / 2^12) / 2^11
	X2 = (AC2 * B6) / 2^11
	X3 = X1 + X2
	B3 = ((((AC1) * 4 + X3) * 2^ OSS) + 2) /4 

    X1 = (AC3 * B6) / 2^13
	X2 = (B1 * ((B6 * B6) / 2^12))/ 2^16
	X3 = ((X1 + X2) + 2) /4
	B4 = (AC4 * (X3 + 32768)) / 2^15

	B7 = ((UP-B3)* (50000 / 2^OSS))

	if (B7 < 0x80000000) then
	   p = (B7 * 2) / B4
	else
	   p = (B7 / B4) *2
	end

	X1 = (p / 2^8) * (p / 2^8)
	X1 = (X1 * 3038) / 2^16
	X2 = (-7357 * p) / 2^16
 	p =  p + ((X1 + X2 + 3791) / 2^4)

	Press = p	-- 将计算结果保存在全局变量

	
	s = string.format('Temp = %4.1f℃， Press = %7.3f KPa', Temp/10, Press/1000) 
	print(s)
end

function bsp_InitBMP085()
	local s
	
	--读出芯片内部的校准参数（每个芯片不同，这是BOSCH出厂前校准好的数据）
	print("---------------------------------------------------------------")
	print("读出芯片内部的校准参数（每个芯片不同，这是BOSCH出厂前校准好的数据）")
	AC1 = BMP085_Read2Bytes(0xAA)
	AC1 = absif(AC1)
	s = string.format('AC1 = %d',AC1) 
	print(s)

	AC2 = BMP085_Read2Bytes(0xAC)
	AC2 = absif(AC2)
	s = string.format('AC2 = %d',AC2) 
	print(s)

	AC3 = BMP085_Read2Bytes(0xAE)
	AC3 = absif(AC3)
	s = string.format('AC3 = %d',AC3) 
	print(s)
	
	AC4 = BMP085_Read2Bytes(0xB0)
	print(AC4)

	AC5 = BMP085_Read2Bytes(0xB2)
	print(AC5)

	AC6 = BMP085_Read2Bytes(0xB4)
	print(AC6)
	
	B1 =  BMP085_Read2Bytes(0xB6)
	B1 = absif(B1)
	s = string.format('B1 = %d',B1) 
	print(s)

	B2 =  BMP085_Read2Bytes(0xB8)
	B2 = absif(B2)
	s = string.format('B2 = %d',B2) 
	print(s)

	MB =  BMP085_Read2Bytes(0xBA)
	MB = absif(MB)
	s = string.format('MB = %d',MB) 
	print(s)

	MC =  BMP085_Read2Bytes(0xBC)
	MC = absif(MC)
	s = string.format('MC = %d',MC) 
	print(s)

	MD =  BMP085_Read2Bytes(0xBE)
	MD= absif(MD)
	s = string.format('MD= %d',MD) 
	print(s)
	print("---------------------------------------------------------------")

	-- 过采样参数，0-3
	OSS = 0
end


----------------------------------------------------------------------
--  应用测试代码
-----------------------------------------------------------------------
bsp_InitBMP085() -- 初始化

-- 连续获取30次并打印
for i = 1, 30, 1 do
    delayms(400)  -- 延迟要加上
    BMP085_ReadTempPress()
end












