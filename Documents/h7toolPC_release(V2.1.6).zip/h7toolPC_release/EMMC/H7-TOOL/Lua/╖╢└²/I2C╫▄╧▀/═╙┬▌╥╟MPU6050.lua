
-------------I2C从机地址 ---------------------------------------------------------------------------
MPU6050_SLAVE_ADDRESS  = 0xD0

----------------------------------------------------------------------------------------------------
--  定义MPU6050内部地址
----------------------------------------------------------------------------------------------------
SMPLRT_DIV	 = 	0x19	--陀螺仪采样率，典型值：0x07(125Hz)
CONFIG		 = 	0x1A	--低通滤波频率，典型值：0x06(5Hz)
GYRO_CONFIG	 = 	0x1B	--陀螺仪自检及测量范围，典型值：0x18(不自检，2000deg/s)

ACCEL_CONFIG = 	0x1C	--加速计自检、测量范围及高通滤波频率，典型值：0x01(不自检，2G，5Hz)

ACCEL_XOUT_H = 	0x3B
ACCEL_XOUT_L = 	0x3C
ACCEL_YOUT_H = 	0x3D
ACCEL_YOUT_L = 	0x3E
ACCEL_ZOUT_H = 	0x3F
ACCEL_ZOUT_L = 	0x40

TEMP_OUT_H	 = 	0x41
TEMP_OUT_L	 = 	0x42

GYRO_XOUT_H	 = 	0x43
GYRO_XOUT_L	 = 	0x44
GYRO_YOUT_H	 = 	0x45
GYRO_YOUT_L	 = 	0x46
GYRO_ZOUT_H	 = 	0x47
GYRO_ZOUT_L	 = 	0x48

PWR_MGMT_1 = 0x6B	-- 电源管理，典型值：0x00(正常启用)
WHO_AM_I  = 0x75	-- IIC地址寄存器(默认数值0x68，只读)


Accel_X = 0  --三轴陀螺仪数据
Accel_Y = 0
Accel_Z = 0
Temp = 0     -- 温度数据 
GYRO_X = 0   -- 三轴加速器数据
GYRO_Y = 0
GYRO_Z = 0

---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------

-- 向 MPU-6050 寄存器写入一个数据
-- _ucRegAddr : 寄存器地址
-- _ucRegData : 寄存器数据
function MPU6050_WriteByte(_ucRegAddr,  _ucRegValue)
	i2c_bus("start")
	i2c_bus("send", MPU6050_SLAVE_ADDRESS)
	i2c_bus("send", _ucRegAddr)
	i2c_bus("send", _ucRegValue)
	i2c_bus("stop")
end

--读取 MPU-6050 数据寄存器， 主程序可以定时调用该程序刷新数据
function  MPU6050_ReadData()

	local byte0, byte1, byte2, byte3, byte4, byte5, byte6, byte7
	local byte8, byte9, byte10, byte11, byte12, byte13

	i2c_bus("start")                          -- 总线开始信号 
	i2c_bus("send", MPU6050_SLAVE_ADDRESS)    -- 发送设备地址+写信号
	i2c_bus("send", ACCEL_XOUT_H)             -- 发送存储单元地址
	
	i2c_bus("start")                          -- 总线开始信号  
	i2c_bus("send",MPU6050_SLAVE_ADDRESS + 1) -- 发送设备地址+读信号
	
	str = i2c_bus("recive", 14)               -- 读出寄存器数据
	
	i2c_bus("stop")
	
	byte0 = tonumber(string.byte(str,1,1))
	byte1 = tonumber(string.byte(str,2,2))
	byte2 = tonumber(string.byte(str,3,3))
	byte3 = tonumber(string.byte(str,4,4))
	byte4 = tonumber(string.byte(str,5,5))
	byte5 = tonumber(string.byte(str,5,5))
	byte6 = tonumber(string.byte(str,6,6))
	byte7 = tonumber(string.byte(str,7,7))
	byte8 = tonumber(string.byte(str,8,8))
	byte9 = tonumber(string.byte(str,9,9))
	byte10 = tonumber(string.byte(str,10,10))
	byte11 = tonumber(string.byte(str,11,11))
	byte12 = tonumber(string.byte(str,12,12))
	byte13 = tonumber(string.byte(str,13,13))
	
	Accel_X = (byte0 * 256) + byte1
	Accel_Y = (byte2 << 8) + byte3
	Accel_Z = (byte4 << 8) + byte5
	
	Temp = (byte6 << 8) + byte7
	
	GYRO_X = (byte8 << 8) + byte9
	GYRO_Y = (byte10<< 8) + byte11
	GYRO_Z = (byte12 << 8) + byte13
	
	
	s0 = string.format("AX=%6d,AY=%6d,AZ=%6d,",
						Accel_X,
						Accel_Y,
						Accel_Z)
	
	s1 = string.format("GX=%6d,GY=%6d,GZ=%6d,T=%6d",					
						GYRO_X,
						GYRO_Y,
						GYRO_Z,
						Temp)
	
	print(s0)
	print(s1)

end

-- 初始化MPU6050
function bsp_InitMPU6050()
	delayms(200) 
	MPU6050_WriteByte(PWR_MGMT_1, 0x00)	-- 解除休眠状态
	MPU6050_WriteByte(SMPLRT_DIV, 0x07)
	MPU6050_WriteByte(CONFIG, 0x06)
	MPU6050_WriteByte(GYRO_CONFIG, 0xE8)
	MPU6050_WriteByte(ACCEL_CONFIG, 0x01)
end


----------------------------------------------------------------------
--  应用测试代码
-----------------------------------------------------------------------
bsp_InitMPU6050() -- 初始化

for i=0,5000,1 do
    delayms(100)  
    MPU6050_ReadData()
end
