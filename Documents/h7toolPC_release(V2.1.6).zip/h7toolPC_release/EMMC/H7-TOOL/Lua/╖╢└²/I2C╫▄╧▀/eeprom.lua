-----AT24C02-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 8	   -- 页面大小(字节) 	 
EE_SIZE	 = 256	       -- 总容量(字节)
EE_ADDR_BYTES = 1	   -- 地址字节个数 	   
EE_ADDR_A8 = 0	       -- 地址字节的高8bit不在首字节
--]]
-----AT24C04-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 16	   -- 页面大小(字节) 	 
EE_SIZE	 = 512	   	   -- 总容量(字节)
EE_ADDR_BYTES = 1	   -- 地址字节个数 	   
EE_ADDR_A8 = 1	       -- 地址字节的高8bit在首字节
--]]
-----AT24C08-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 16	   -- 页面大小(字节) 	 
EE_SIZE	 = 1*1024	   -- 总容量(字节)
EE_ADDR_BYTES = 1	   -- 地址字节个数 	   
EE_ADDR_A8 = 1	       -- 地址字节的高8bit在首字节
--]]
-----AT24C16-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 16	   -- 页面大小(字节) 	 
EE_SIZE	 = 2*1024	   -- 总容量(字节)
EE_ADDR_BYTES = 1	   -- 地址字节个数 	   
EE_ADDR_A8 = 1	       -- 地址字节的高8bit在首字节
--]]
-----AT24C32-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 32	   -- 页面大小(字节) 	 
EE_SIZE	 = 4*1024	   -- 总容量(字节)
EE_ADDR_BYTES = 2	   -- 地址字节个数 	   
EE_ADDR_A8 = 0	       -- 地址字节的高8bit不在首字节
--]]
-----AT24C64-----------------------------------------------------------------------------------------
--[[
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 32	   -- 页面大小(字节) 	 
EE_SIZE	 = 8*1024	   -- 总容量(字节)
EE_ADDR_BYTES = 2	   -- 地址字节个数 	   
EE_ADDR_A8 = 0	       -- 地址字节的高8bit不在首字节
--]]
-----AT24C128-----------------------------------------------------------------------------------------
EE_DEV_ADDR = 0xA0	  	
EE_PAGE_SIZE = 64			 
EE_SIZE	 = 16*1024	
EE_ADDR_BYTES = 2			   
EE_ADDR_A8 = 0	

------------------------------------------------------------------------------------------------------
I2C_WR = 0	  -- 写操作
I2C_RD = 1    -- 读操作
------------------------------------------------------------------------------------------------------

-- 从串行EEPROM指定地址处开始读取若干数据
-- _usAddress : 起始地址
-- _usSize : 数据长度，单位为字节
function ee_ReadBytes(_usAddress,  _usSize)

	local ack

	-- 采用串行EEPROM随即读取指令序列，连续读取若干字节
	--  第1步：发起I2C总线启动信号 
	i2c_bus("start")
	
	--  第2步：发起控制字节，高7bit是地址，bit0是读写控制位，0表示写，1表示读 
	if (EE_ADDR_A8 == 1) then  
		ack = i2c_bus("send", EE_DEV_ADDR | I2C_WR | ((_usAddress >> 7) & 0x0E))
	else
		ack = i2c_bus("send", EE_DEV_ADDR | I2C_WR) 
	end

	if (ack ~= 0) then
		print("EEPROM器件无应答")
		goto cmd_fail	-- EEPROM器件无应答
	end


	--  第3步：发送字节地址，24C02只有256字节，因此1个字节就够了，如果是24C04以上，那么此处需要连发多个地址 
	if (EE_ADDR_BYTES == 1) then  
		ack = i2c_bus("send", _usAddress)
		if (ack ~= 0) then
			print("EEPROM器件无应答")
			goto cmd_fail	-- EEPROM器件无应答
		end
	else
		ack = i2c_bus("send", (_usAddress >> 8) & 0xFF)
		if (ack ~= 0) then
			print("EEPROM器件无应答")
			goto cmd_fail	-- EEPROM器件无应答
		end
	
		ack = i2c_bus("send", _usAddress & 0xFF)
		if (ack ~= 0) then
			print("EEPROM器件无应答")
			goto cmd_fail	-- EEPROM器件无应答
		end
	end

	-- 第4步：重新启动I2C总线。下面开始读取数据
	i2c_bus("start")

	-- 第5步：发起控制字节，高7bit是地址，bit0是读写控制位，0表示写，1表示读 
	if (EE_ADDR_A8 == 1) then  
		ack = i2c_bus("send", EE_DEV_ADDR |  I2C_RD | ((_usAddress >> 7) & 0x0E)) -- 此处是读指令 
	else
		ack = i2c_bus("send", EE_DEV_ADDR |  I2C_RD)  -- 此处是读指令 
	end

	if (ack ~= 0) then
		print("EEPROM器件无应答")
		goto cmd_fail	-- EEPROM器件无应答
	end

	-- 读取数据
     str = i2c_bus("recive", _usSize)

	-- 打印读取的数据
	print("读取的数据如下:")
	print_hex(str, 128, 0)

::cmd_fail:: 
	--  命令执行失败后，切记发送停止信号，避免影响I2C总线上其他设备 
	--  发送I2C总线停止信号 
	i2c_bus("stop")

end

--  向串行EEPROM指定地址写入若干数据，采用页写操作提高写入效率
--  _pWriteBuf : 存放读到的数据的缓冲区指针
-- _usAddress : 起始地址
-- _usSize : 数据长度，单位为字节
function ee_WriteBytes(_pWriteBuf,  _usAddress,  _usSize)
	local i, m
	local usAddr
	local ack
	local res

               
	-- 写串行EEPROM不像读操作可以连续读取很多字节，每次写操作只能在同一个page。
	-- 对于24xx02，page size = 8
	-- 简单的处理方法为：按字节写操作模式，每写1个字节，都发送地址
	-- 为了提高连续写的效率: 本函数采用page wirte操作。
	
	print("写入数据:")
	res = string.format("%s",  bin2hex(_pWriteBuf))
	print(res)

	usAddr = _usAddress

	for i=0,  _usSize, 1 do
   	  
		--  当发送第1个字节或是页面首地址时，需要重新发起启动信号和地址 
		if ((i == 0) or (usAddr & (EE_PAGE_SIZE - 1)) == 0) then  
			-- 第1步：发停止信号，启动内部写操作
			i2c_bus("stop")

			-- 通过检查器件应答的方式，判断内部写操作是否完成, 一般小于 10ms CLK频率为200KHz时，查询次数为30次左右 
            for m=1,  1000, 1 do
                -- 发起I2C总线启动信号
			    i2c_bus("start")

				--  发起控制字节，高7bit是地址，bit0是读写控制位，0表示写，1表示读 
				if (EE_ADDR_A8 == 1) then  
					ack =   i2c_bus("send", EE_DEV_ADDR | I2C_WR | ((_usAddress >> 7) & 0x0E)) --  此处是写指令 
				else
					ack =  i2c_bus("send", EE_DEV_ADDR | I2C_WR)  -- 此处是写指令 
				end

				-- 发送一个时钟，判断器件是否正确应答
				if (ack  == 0) then
				    break
                end

        	end

			if (m  == 1000) then
				print("EEPROM器件写超时 \r\n")
				goto cmd_fail	-- EEPROM器件写超时 
			end

			-- 发送字节地址，24C02只有256字节，因此1个字节就够了，如果是24C04以上，那么此处需要连发多个地址 
			if (EE_ADDR_BYTES == 1) then 
			    ack = i2c_bus("send", usAddr) 
				if (ack ~= 0) then
					print("EEPROM器件无应答")
					goto cmd_fail	-- EEPROM器件无应答 
				end
	
			else
			    ack = i2c_bus("send", (usAddr >> 8)&0xFF) 
				if (ack ~= 0) then
					print("EEPROM器件无应答")
					goto cmd_fail	-- EEPROM器件无应答
				end

				ack = i2c_bus("send", usAddr &0xFF) 
				if (ack ~= 0) then
					print("EEPROM器件无应答")
					goto cmd_fail	-- EEPROM器件无应答
				end
			end
  
  
        end

         --  开始写入数据 
        res = string.sub(_pWriteBuf,  i+1, i+1)	
		ack = i2c_bus("send", res) 

		if (ack ~= 0) then
			print("EEPROM器件无应答")
		    goto cmd_fail	-- EEPROM器件无应答 
		end

		usAddr = usAddr + 1  -- 地址增1
	
	end

	-- 命令执行成功，发送I2C总线停止信号
	i2c_bus("stop")

	-- 通过检查器件应答的方式，判断内部写操作是否完成, 一般小于 10ms CLK频率为200KHz时，查询次数为30次左右
	for m=1, 1000, 1 do
		--  发起I2C总线启动信号
		i2c_bus("start")
		
		-- 发起控制字节，高7bit是地址，bit0是读写控制位，0表示写，1表示读 
		if (EE_ADDR_A8 == 1) then  
			ack =   i2c_bus("send", EE_DEV_ADDR | I2C_WR | ((_usAddress >> 7) & 0x0E)) --  此处是写指令 
		else
			ack =  i2c_bus("send", EE_DEV_ADDR | I2C_WR)  -- 此处是写指令 
		end

		-- 发送一个时钟，判断器件是否正确应答 
		if (ack == 0) then
			break
		end

    end

	if (m  == 1000) then
		print("EEPROM器件无应答")
		goto cmd_fail	-- EEPROM器件写超时
	end

::cmd_fail:: 
	--  命令执行失败后，切记发送停止信号，避免影响I2C总线上其他设备 
	--  发送I2C总线停止信号 
	i2c_bus("stop")

end

----------------------------------------------------------------------
--  应用测试代码
-----------------------------------------------------------------------
print("=======================================================")
ee_WriteBytes("\xf0\x00\x11\x22\x33\xf0\x00\xDD\x22\x33", 0, 10)
ee_ReadBytes(0, 10)
