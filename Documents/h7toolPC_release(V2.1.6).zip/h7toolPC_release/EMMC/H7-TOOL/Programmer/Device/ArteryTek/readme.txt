
2021-12-08
1、增加STM32F435, STM32F437
  - 测试 STM32F437RMT7. OK，整片擦除时间长, 不支持STM32 CRC校验模式，用软件校验模式OK
  - 测试STM32F435CGT7. OK. 不支持STM32 CRC校验模式，用软件校验模式OK
  - 解除读保护和写保护 OK
  - 读保护后，OB读回为全FF