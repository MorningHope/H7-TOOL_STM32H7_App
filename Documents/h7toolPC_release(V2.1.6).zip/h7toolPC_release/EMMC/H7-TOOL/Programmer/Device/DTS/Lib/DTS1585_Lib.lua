-------------------------------------------------------
-- 文件名 : DTS1585_Lib.lua
-- 版  本 : V1.0  2020-07-18
-- 说  明 : 
-------------------------------------------------------

--没有UID，固定返回0

--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"
	local i

	print("InitUnderReset()")

	-- 0x40000070写为0x10000关闭看门狗时钟, 5秒超时
	print(" --Close the dog clock")
	for i = 0, 100, 1 do
		if (pg_write32(0x40000070, 0x10000) == 1) then			
			break	  --成功返回，不成功继续
		end
		print(" retry close dog", i)
		print_core_id()
		
		delayms(50) --延迟50ms再试
	end
	
	delayms(10)
	
	--0x4000010C写0，解除M4内核软件复位屏蔽
	print(" --Enable M4 soft reset")
	for i = 0, 10, 1 do
		if (pg_write32(0x4000010C, 0) == 1) then			
			break	  --成功返回，不成功继续
		end
		print(" retry 0x4000010C = 0", i)
		
		delayms(10) --延迟10ms再试
	end

	if (ReadDeviceID() ~= 0) then
		goto quit_err
	end

::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	

	str = "..DeviceID = DTS1585 "
	

	print(str)
	return 0
end

---------------------------结束-----------------------------------
