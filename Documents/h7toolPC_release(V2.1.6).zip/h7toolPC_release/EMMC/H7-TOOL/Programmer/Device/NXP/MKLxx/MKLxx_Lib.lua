-------------------------------------------------------
-- 文件名 : MKLxx_Lib.lua
-- 版  本 : V1.1  2022-01-11
-- 说  明 : 
-------------------------------------------------------


--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"

	print("InitUnderReset()")

	-- if (pg_write32(0x40015804, 0x00000006) == 0) then
		-- goto quit_err
	-- end

	-- if (pg_write32(0x40015808, 0x00001800) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

	MKL_CheckSwd()

	print("WDP8_SELECT=0x01000000, WAP4_TAR = 0x00000014")
	
	pg_swd("WDP", DP8_SELECT, MDM_AP_STATUS)
	pg_swd("WAP", AP4_TAR, 0x00000014)
	pg_swd("RAP", 0)
	pg_swd("RDP", DP_RDBUFF)
	--pg_swd("WAP", AP4_TAR, 0x00000004)
	
	pg_swd("WDP", DP8_SELECT, 0)
	
::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x40015800)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP0_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP0_ABORT		= 0x00	--Abort Register (SW Write only)
	DP4_CTRL_STAT= 0x04	--Control & Status
	DP4_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP8_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP8_RESEND 	= 0x08	--Resend (SW Read Only)
	DPc_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP0_CSW = 0x00	--Control and Status Word
	AP4_TAR = 0x04	--Transfer Address	
	AP8	 = 0X08	
	APc_DRW = 0x0C	--Data Read/Write
	AP_BD0 = 0x10	--Banked Data 0
	AP_BD1 = 0x14	--Banked Data 1
	AP_BD2 = 0x18	--Banked Data 2
	AP_BD3 = 0x1C	--Banked Data 3
	AP_ROM = 0xF8	--Debug ROM Address
	AP_IDR = 0xFC	--Identification Register
	
	--MKE系列 9.3 SWD status and control registers
	MDM_AP_STATUS = 0x01000000
	MDM_AP_CONTROL = 0x01000004
	MDM_AP_IDR = 0x010000FC		--固定返回 0x001C_0020
	
	--MKL系列
	
end

function MKL_CheckSwd(void)
	local idr
	
	pg_reset_pin(0)	--拉低复位口线读取

	print_core_id() --使能SWD

	idr = AP_IDR
	pg_swd("WDP", DP8_SELECT, MDM_AP_IDR)
	idr = pg_swd("RAP", AP_IDR)
	print(string.format("AP_IDR = 0x0%08X", idr)) --正确时返回 001C0020
end

--芯片加密判断 1表示已保护
function MCU_CheckProtect(void)
	return 1
end

--解除芯片加密
function MCU_RemoveProtect(void)
	local i
	local val = {}	
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end	
	
	print("MKLXX Unsecure Chip begin")
	
	pg_reset_pin(1)	--拉低复位口线
	
	delayms(10)
	
	--EnterDebugProgram()
	
	--print_core_id()  这个有显示
	--pg_detect_ic() --无显示
	
	pg_swd("JTAG2SWD")
	pg_swd("RDP", DP0_IDCODE) --0x0bc11477
	pg_swd("RDP", DP4_CTRL_STAT) --0x00000000
	pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
	pg_swd("WDP", DP0_ABORT, 0x0000001e)
	pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
	pg_swd("RDP", DP4_CTRL_STAT) --0xf0000000
	pg_swd("WDP", DP8_SELECT, 0x01000000)
	pg_swd("RAP", AP0_CSW) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000034
	pg_swd("RAP", AP0_CSW) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000034
	delayms(50)
	pg_swd("WAP", AP4_TAR, 0x00000010) --0x00000010
	pg_swd("RAP", AP4_TAR) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000000
	pg_swd("RAP", AP0_CSW) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000034
	delayms(100) --延迟1秒? 
	pg_swd("WAP", AP4_TAR, 0x00000009) --0x00000009
	pg_swd("RAP", AP0_CSW) --0x00000009
	pg_swd("RDP", DPc_RDBUFF) --0x00000034
	pg_swd("RAP", AP0_CSW) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000037
	pg_swd("RAP", AP4_TAR) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000009

	--等待AP4 的bit0值由1变为0
	for i = 0, 300, 1 do
		local err
		
		pg_swd("RAP", AP4_TAR)
		val = {pg_swd("RDP", DPc_RDBUFF)} 
		err = 0
		for j = 1, ch_num, 1 do
			--print_hex(val[j])
			if ((val[j] & 0x01) == 0x01) then
				err = 1
			end
		end
		delayms(20)
		if (err == 0) then
			break
		end
	end	
	
	pg_swd("RAP", AP0_CSW) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000033
	pg_swd("RAP", AP4_TAR) --0x00000000
	pg_swd("RDP", DPc_RDBUFF) --0x00000008
	pg_swd("WDP", DP8_SELECT, 0x00000000)
	
	--全局变量，解除读保护后，无需写入缺省OB, 全FF
	IGNORE_WRITE_OB_SECURE_OFF = 1
	
	pg_reset_pin(0)	--复位口线
	
	delayms(100)--需要延迟
	
	EnterDebugProgram()
	pg_detect_ic() --加上后才能读UID
	
	print("MKLXX Unsecure Chip end")
end


--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP0_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP0_ABORT		= 0x00	--Abort Register (SW Write only)
	DP4_CTRL_STAT= 0x04	--Control & Status
	DP4_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP8_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP8_RESEND 	= 0x08	--Resend (SW Read Only)
	DPc_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP0_CSW = 0x00	--Control and Status Word
	AP4_TAR = 0x04	--Transfer Address	
	AP8     = 0X08	
	APc_DRW = 0x0C	--Data Read/Write
	AP10_BD0 = 0x10	--Banked Data 0
	AP14_BD1 = 0x14	--Banked Data 1
	AP18_BD2 = 0x18	--Banked Data 2
	AP1c_BD3 = 0x1C	--Banked Data 3
	APf8_ROM = 0xF8	--Debug ROM Address
	APfc_IDR = 0xFC	--Identification Register
	
	--
	DBG_HCSR = 0xe000edf0
	DBG_CRSR = 0xe000edf4
	DBG_CRDR = 0xe000edf8
	DBG_EMCR = 0xe000edfc
	
	NVIC_Addr  = 0xe000e000
	NVIC_ICT   = 0xe000e004
	NVIC_CPUID = 0xe000ed00
	NVIC_AIRCR = 0xe000ed0c --NVIC: Application Interrupt/Reset Control Register	
	NVIC_DFSR  = 0xe000ed30
	
	DWT_PCSR   = 0xe000101c
	
	--MKE系列 9.3 SWD status and control registers
	MDM_AP_STATUS = 0x01000000
	MDM_AP_CONTROL = 0x01000004
	MDM_AP_IDR = 0x010000FC		--固定返回 0x001C_0020
	
	--MKL系列	
end

function EnterDebugProgram(void)

	local powered_down = 0
	local re = {}
	local i

	print("lua EnterDebugProgram()")
		--
pg_swd("WAP", AP4_TAR, 0xe000ed0c) --NVIC_AIRCR
--LINERESET
pg_swd("JTAG2SWD")
--LINERESET
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
pg_swd("WDP", DP0_ABORT, 0x0000000c)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP4_CTRL_STAT, 0x50000f00)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x0000003a
pg_swd("WAP", AP4_TAR, 0x00000014) --0x00000014
pg_swd("RDP", DPc_RDBUFF) --0x00000014
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x000000f0)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x04770031
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP0_CSW, 0x23000060)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03000040
pg_swd("WAP", AP0_CSW, 0x23000061)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03000041
pg_swd("WAP", AP0_CSW, 0x23000052)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x000000f0)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", AP8) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xf0002003
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xf0002ff0) --0xf0002ff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000010
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0002fd0) --0xf0002fd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000008
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0002000) --0xf0002000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xffffe003
pg_swd("WAP", AP4_TAR, 0xf0000ff0) --0xf0000ff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0000fd0) --0xf0000fd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000032
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0002004) --0xf0002004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfffff003
pg_swd("WAP", AP4_TAR, 0xf0001ff0) --0xf0001ff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0001fd0) --0xf0001fd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000008
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xf0002008) --0xf0002008
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xf00fd003
pg_swd("WAP", AP4_TAR, 0xe00ffff0) --0xe00ffff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000010
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe00fffd0) --0xe00fffd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x000000c0
pg_swd("RAP", APc_DRW) --0x000000b4
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe00ff000) --0xe00ff000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff0f003
pg_swd("WAP", AP4_TAR, 0xe000eff0) --0xe000eff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe000efd0) --0xe000efd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000008
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe00ff004) --0xe00ff004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff02003
pg_swd("WAP", AP4_TAR, 0xe0001ff0) --0xe0001ff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe0001fd0) --0xe0001fd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000a
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe00ff008) --0xe00ff008
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff03003
pg_swd("WAP", AP4_TAR, 0xe0002ff0) --0xe0002ff0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe0002fd0) --0xe0002fd0
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe00ff00c) --0xe00ff00c
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xf000200c) --0xf000200c
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000ed00) --NVIC_CPUID
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x410cc600
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x00000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0x00000000) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000020
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x20000000
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("WAP", APc_DRW, 0x0000001f)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x0000001f
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("WAP", APc_DRW, 0x00000002)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x00000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000ed0c) --NVIC_AIRCR
pg_swd("WAP", APc_DRW, 0x05fa0004)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
delayms(100)
end

SWD_RegDefine()

---------------------------结束-----------------------------------
