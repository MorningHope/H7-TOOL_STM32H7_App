-------------------------------------------------------
-- 文件名 : MKExx_Lib_0.lua
-- 版  本 : V1.0  2021-09-22
-- 说  明 : 不能用这个文件
-------------------------------------------------------


--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"

	print("InitUnderReset() --none")

	-- if (pg_write32(0x40015804, 0x00000006) == 0) then
		-- goto quit_err
	-- end

	-- if (pg_write32(0x40015808, 0x00001800) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x40015800)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP0_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP0_ABORT		= 0x00	--Abort Register (SW Write only)
	DP4_CTRL_STAT= 0x04	--Control & Status
	DP4_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP8_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP8_RESEND 	= 0x08	--Resend (SW Read Only)
	DPc_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP0_CSW = 0x00	--Control and Status Word
	AP4_TAR = 0x04	--Transfer Address	
	AP8	 = 0X08	
	APc_DRW = 0x0C	--Data Read/Write
	AP_BD0 = 0x10	--Banked Data 0
	AP_BD1 = 0x14	--Banked Data 1
	AP_BD2 = 0x18	--Banked Data 2
	AP_BD3 = 0x1C	--Banked Data 3
	AP_ROM = 0xF8	--Debug ROM Address
	AP_IDR = 0xFC	--Identification Register
	
	--MKE系列 9.3 SWD status and control registers
	MDM_AP_STATUS = 0x01000000
	MDM_AP_CONTROL = 0x01000004
	MDM_AP_IDR = 0x010000FC		--固定返回 0x001C_0020
	
	--MKL系列
end

--芯片加密判断
function MCU_CheckProtect(void)
	return 1
end

--解除芯片加密
function MCU_RemoveProtect(void)
	local i
	local val = {}	
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end	
	
	print("MKEXX Unsecure Chip begin")
	print_core_id()
	
	SWD_RegDefine()
	
pg_reset_pin(1)	--拉低复位口线
	
	delayms(10)
	
	--EnterDebugProgram()
	
	--print_core_id()  这个有显示
	--pg_detect_ic() --无显示
	
pg_swd("JTAG2SWD")
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
pg_swd("RDP", DP4_CTRL_STAT) --0x00000000
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000000
pg_swd("WDP", DP8_SELECT, 0x01000000)
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000034
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000034
delayms(50)	
	
--	pg_swd("WDP", DP8_SELECT, 0x01000000)
	
pg_swd("WAP", AP4_TAR, 0x00000001) --0x00000001
pg_swd("RAP", AP0_CSW) --0x00000001
pg_swd("RDP", DPc_RDBUFF) --0x0000000f
pg_swd("WAP", AP4_TAR, 0x00000000) --0x00000000
delayms(101)	
		
	--等待AP4 的bit0值由1变为0
	for i = 0, 300, 1 do
		local err
		
		pg_swd("RAP", AP4_TAR)
		val = {pg_swd("RDP", DPc_RDBUFF)} 
		err = 0
		for j = 1, ch_num, 1 do
			if ((val[j] & 0x01) == 0x01) then
				err = 1
			end
		end
		delayms(20)
		if (err == 0) then
			break
		end
	end	
	
delayms(52)
pg_swd("WAP", AP4_TAR, 0x00000008) --0x00000008
pg_swd("RAP", AP0_CSW) --0x00000008
pg_swd("RDP", DPc_RDBUFF) --0x00000001
pg_swd("RAP", AP4_TAR) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000008
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0001)
pg_swd("WDP", DP8_SELECT, 0x01000000)
pg_swd("WAP", AP4_TAR, 0x00000014) --0x00000014
pg_swd("WAP", AP4_TAR, 0x00000004) --0x00000004

pg_reset_pin(0)	--复位恢复

delayms(101)
pg_swd("RAP", AP0_CSW) --0x00000004
pg_swd("RDP", DPc_RDBUFF) --0x0001000b
pg_swd("WAP", AP4_TAR, 0x00000000) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0x00000408) --0x00000408
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xffffffff
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x02000001
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03030003
pg_swd("WAP", AP0_CSW, 0x23000000)
pg_swd("WAP", AP4_TAR, 0x40052000) --0x40052000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000080
pg_swd("WAP", AP4_TAR, 0x40052004) --0x40052004
pg_swd("WAP", APc_DRW, 0xffffffff)
pg_swd("WAP", AP4_TAR, 0x40052005) --0x40052005
pg_swd("WAP", APc_DRW, 0xffffffff)
pg_swd("WAP", AP4_TAR, 0x40052006) --0x40052006
pg_swd("WAP", APc_DRW, 0xffffffff)
pg_swd("WAP", AP4_TAR, 0x40052007) --0x40052007
pg_swd("WAP", APc_DRW, 0xffffffff)
pg_swd("WAP", AP4_TAR, 0x40052001) --0x40052001
pg_swd("WAP", APc_DRW, 0x01010101)
pg_swd("WAP", AP4_TAR, 0x40052000) --0x40052000
pg_swd("WAP", APc_DRW, 0x20202020)
pg_swd("WAP", AP0_CSW, 0x23000002)
	
	delayms(100)
	
	--全局变量，解除读保护后，无需写入缺省OB, 全FF
	IGNORE_WRITE_OB_SECURE_OFF = 1
	
--	pg_detect_ic()
	
	print("MKEXX Unsecure Chip end")
end


function EnterDebugProgram(void)

	local powered_down = 0
	local re = {}
	local i

	print("lua EnterDebugProgram()")
		--
--LINERESET
pg_swd("JTAG2SWD")
--LINERESET
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x000000f0)
pg_swd("WDP", DP8_SELECT, 0x000000f0)
pg_swd("RAP", AP8) --0x00000000
pg_swd("RAP", AP8) --0xf0002003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000ed00) --NVIC_CPUID
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x410cc600
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000ed0c) --NVIC_AIRCR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfa050000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000020
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x01000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x20000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("WAP", APc_DRW, 0x20000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xf0002000) --0xf0002000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0xffffe003
pg_swd("RAP", APc_DRW) --0xfffff003
pg_swd("RAP", APc_DRW) --0xf00fd003
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xf0000ff0) --0xf0000ff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xf0000fe0) --0xf0000fe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000032
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xf0001ff0) --0xf0001ff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xf0001fe0) --0xf0001fe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000008
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe00ffff0) --0xe00ffff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000010
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe00fffe0) --0xe00fffe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x000000c0
pg_swd("RAP", APc_DRW) --0x000000b4
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe00ff000) --0xe00ff000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0xfff0f003
pg_swd("RAP", APc_DRW) --0xfff02003
pg_swd("RAP", APc_DRW) --0xfff03003
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000eff0) --0xe000eff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000efe0) --0xe000efe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000008
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001ff0) --0xe0001ff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001fe0) --0xe0001fe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000a
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0002ff0) --0xe0002ff0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0002fe0) --0xe0002fe0
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000ed0c) --NVIC_AIRCR
pg_swd("WAP", APc_DRW, 0x05fa0004)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP4_CTRL_STAT, 0xf0000000)
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x03030003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WDP", DP8_SELECT, 0x00000010)
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x00030003
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000002)
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WDP", DP8_SELECT, 0x00000010)
pg_swd("WAP", AP4_TAR, 0x00000000) --0x00000000
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfffbf7ff
pg_swd("WAP", AP4_TAR, 0x00000001) --0x00000001
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffe7ffbf
pg_swd("WAP", AP4_TAR, 0x00000002) --0x00000002
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0x7f0ff7ff
pg_swd("WAP", AP4_TAR, 0x00000003) --0x00000003
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xbfefeef7
pg_swd("WAP", AP4_TAR, 0x00000004) --0x00000004
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfbffffff
pg_swd("WAP", AP4_TAR, 0x00000005) --0x00000005
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xdffff7ff
pg_swd("WAP", AP4_TAR, 0x00000006) --0x00000006
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffffd7fb
pg_swd("WAP", AP4_TAR, 0x00000007) --0x00000007
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffdbf7ef
pg_swd("WAP", AP4_TAR, 0x00000008) --0x00000008
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xdfc5e5fb
pg_swd("WAP", AP4_TAR, 0x00000009) --0x00000009
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffffffff
pg_swd("WAP", AP4_TAR, 0x0000000a) --0x0000000a
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffffffff
pg_swd("WAP", AP4_TAR, 0x0000000b) --0x0000000b
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xffffffe5
pg_swd("WAP", AP4_TAR, 0x0000000c) --0x0000000c
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xebfdf7f7
pg_swd("WAP", AP4_TAR, 0x0000000e) --0x0000000e
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfffffff9
pg_swd("WAP", AP4_TAR, 0x0000000f) --0x0000000f
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfffffffe
pg_swd("WAP", AP4_TAR, 0x00000010) --0x00000010
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xf1000000
pg_swd("WAP", AP4_TAR, 0x00000011) --0x00000011
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfffffffc
pg_swd("WAP", AP4_TAR, 0x00000012) --0x00000012
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0xfbf3987c
pg_swd("WAP", AP4_TAR, 0x00000014) --0x00000014
pg_swd("RAP", AP0_CSW) --0x00000000
pg_swd("RAP", AP0_CSW) --0x01030003
pg_swd("RAP", AP8) --0x00030003
pg_swd("RAP", AP8) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("WAP", APc_DRW, 0x00000003)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x01000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x20000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("WDP", DP8_SELECT, 0x00000000)
pg_swd("WAP", AP0_CSW, 0x23000012)
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("WAP", APc_DRW, 0x20000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
pg_swd("RDP", DP0_IDCODE) --0x0bc11477
delayms(100)
end

---------------------------结束-----------------------------------
