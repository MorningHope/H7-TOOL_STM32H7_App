
2021-12-24 
（1）验证 HK32F030MF4P6 .OK
  - 16KB Flash，超过16K读写失败
  - 支持STM32 硬件CRC32
  - page只有2字节，写完整的OB区需要多次操作
  - Erased Content : 0xAA, 因此每次编程需要执行擦除函数
  - OB区比ST的多一些字节

（2）验证 HK32F030F4P6  OK
  - 16KB Flash，实测可用64KB
  - 支持STM32 硬件CRC32
  - 选项字只做了前面16字节。后面的区域可以用OPT算法写入文件方式操作, 不在界面上配置