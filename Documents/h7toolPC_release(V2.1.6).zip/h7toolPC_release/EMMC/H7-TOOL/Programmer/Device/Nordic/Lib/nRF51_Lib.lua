-------------------------------------------------------
-- 文件名 : nRF51_Lib.lua
-- 版  本 : V1.0  2021-12-13
-- 说  明 : 安富莱电子
-------------------------------------------------------

--没有UID，固定返回0

--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"
	local RCC_APB1ENR_M3M0_M3N4 =  0x4002101C
	
	print("InitUnderReset()")
	
	--print("0x4001E000 + 0x504 = 0x02")
	--pg_write32(0x4001E000 + 0x504, 0x02)

	--403A 407系列缺省没有开PWR标志位
	-- if (pg_write32(RCC_APB1ENR_M3M0_M3N4, 0x10000000) == 0) then
		-- goto quit_err
	-- end
	
	-- if (pg_write32(0xE0042004, 0x00000307) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

	ReadDeviceID()
	
::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x10000100)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP_ABORT		= 0x00	--Abort Register (SW Write only)
	DP_CTRL_STAT= 0x04	--Control & Status
	DP_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP_RESEND 	= 0x08	--Resend (SW Read Only)
	DP_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP_CSW = 0x00	--Control and Status Word
	AP_TAR = 0x04	--Transfer Address	
	AP_8	 = 0X08	
	AP_DRW = 0x0C	--Data Read/Write
	AP_BD0 = 0x10	--Banked Data 0
	AP_BD1 = 0x14	--Banked Data 1
	AP_BD2 = 0x18	--Banked Data 2
	AP_BD3 = 0x1C	--Banked Data 3
	AP_ROM = 0xF8	--Debug ROM Address
	AP_IDR = 0xFC	--Identification Register
end


--DP AP寄存器定义
function NRF51_RegDefine(void)
	NRF5_NVMC_BASE = 0x4001E000 --Non-Volatile Memory ontroller Registers
	NRF5_NVMC_READY	= 0x4001E400
	NRF5_NVMC_CONFIG	= 0x4001E504
	NRF5_NVMC_ERASEPAGE	= 0x4001E508
	NRF5_NVMC_ERASEALL	= 0x4001E50C
	NRF5_NVMC_ERASEUICR	= 0x4001E514

	NRF5_BPROT_BASE = 0x40000000
	
	WATCHDOG_REFRESH_REGISTER = 0x40010600
	WATCHDOG_REFRESH_VALUE = 0x6e524635
	WATCHDOG_CRV  = 0x40010504 -- Counter reload value
end

--芯片专有的解除保护函数, CTRL-AP
function MCU_RemoveProtect(void)
	local i
	local val = {}	
	local j
	local ch_num
	local err

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end	
	
	NRF51_RegDefine()

	pg_write32(WATCHDOG_CRV, 0x0FFFFFFF)
	pg_write32(WATCHDOG_REFRESH_REGISTER, WATCHDOG_REFRESH_VALUE)

	pg_write32(0x40000524, 0xF)		--读回是3
	
	pg_write32(NRF5_NVMC_CONFIG, 0x00000002)		
	
	pg_write32(NRF5_NVMC_ERASEALL, 0x00000001)

  --
	err = 1
 	for i = 1, 500, 1 do
 		if (pg_read32(NRF5_NVMC_READY) == 1) then
			print("Mass erase completed.")
			err = 0
 			break
 		end
 		delayms(1)
	end	
	
	if (err == 1) then
		print("Error waiting NVMC_READY.")
	end
	
	--max = 22.3 ms
	delayms(50)	

	--全局变量，解除读保护后，无需写入缺省OB, 全FF
	IGNORE_WRITE_OB_SECURE_OFF = 1
end

--芯片专有的整片擦除
function MCU_EraseMass(void)
	MCU_RemoveProtect()
	return "OK"
end

--编程page间隙喂狗（NRF51的FLM)
function MCU_FeedDog(void)
	pg_write32(WATCHDOG_REFRESH_REGISTER, WATCHDOG_REFRESH_VALUE)
	--print("+")
end

---------------------------结束-----------------------------------
