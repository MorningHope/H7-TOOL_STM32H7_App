-------------------------------------------------------
-- 文件名 : CY8C4_Lib.lua
-- 版  本 : V1.0  2020-07-18
-- 说  明 : 资料不全，未做完。 读写保护不支持
-------------------------------------------------------
CM0_ISER_REG_REG = 0xE000E100
CPUSS_CONFIG_REG = 0x40100000
CPUSS_SYSREQ_REG = 0x40100004
CPUSS_SYSARG_REG = 0x40100008

-- Write_DAP (Register, Data32)
-- Read_DAP (Register, out Data32)

--WriteIO Subroutine
-- function WriteIO(addr32, data32)

	-- pg_swd("WDP", TAR, val)
	-- pg_swd("WDP", adr, data32)

	-- ack1 = Write_DAP (TAR, addr32);
	-- ack2 = Write_DAP (DRW, data32);
	-- return (ack1 == 3’b001) && (ack2 == 3b’001);
-- end

-- // “ReadIO” Subroutine
-- bool ReadIO (addr32, OUT data32)
-- {
-- ack1 = Write_DAP (TAR, addr32);
-- ack2 = Read_DAP (DRW, OUT data32);

-- ack3 = Read_DAP (DRW, OUT data32);
-- return (ack1 == 3’b001) && (ack2 == 3b’001) && (ack3 == 3b’001);
-- }
-- // “PollSROMStatus” Subroutine
-- bool PollSROMStatus()
-- {
-- do
-- {
-- ReadIO (CPUSS_SYSREQ, OUT status);
-- Status &= (SROM_SYSREQ_BIT | SROM_PRIVILEGED_BIT);
-- }while ((status != 0) && (time_elapsed < 1 sec));
-- if (time_elapsed >= 1 sec ) return FAIL; // timeout
-- ReadIO (CPUSS_SYSARG, OUT statusCode);
-- if ((statusCode & 0xF0000000) != (SROM_STATUS_SUCCEEDED))
-- {
-- return FAIL; // SROM command failed
-- }
-- else return PASS; // SROM command succeeded
-- }



        -- pg_swd("WAP", adr, val)
        -- pg_swd("WDP", adr, val)
        -- pg_swd("RDP", adr)
        -- pg_swd("RAP", adr)
				

--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"

	print("InitUnderReset()")

	--403A 407系列缺省没有开PWR标志位
	-- if (pg_write32(RCC_APB1ENR_M3M0_M3N4, 0x10000000) == 0) then
		-- goto quit_err
	-- end
	
	-- if (pg_write32(0xE0042004, 0x00000307) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x40015800)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

---------------------------结束-----------------------------------
