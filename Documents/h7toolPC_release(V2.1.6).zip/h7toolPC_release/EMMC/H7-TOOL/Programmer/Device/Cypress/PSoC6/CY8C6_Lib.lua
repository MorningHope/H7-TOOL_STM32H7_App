-------------------------------------------------------
-- 文件名 : CY8C46_Lib.lua
-- 版  本 : V1.0  2020-07-18
-- 说  明 :  
-------------------------------------------------------
CM0_ISER_REG_REG = 0xE000E100
CPUSS_CONFIG_REG = 0x40100000
CPUSS_SYSREQ_REG = 0x40100004
CPUSS_SYSARG_REG = 0x40100008


--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"

	print("InitUnderReset()")

	--403A 407系列缺省没有开PWR标志位
	-- if (pg_write32(RCC_APB1ENR_M3M0_M3N4, 0x10000000) == 0) then
		-- goto quit_err
	-- end
	
	-- if (pg_write32(0xE0042004, 0x00000307) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x40015800)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP0_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP0_ABORT		= 0x00	--Abort Register (SW Write only)
	DP4_CTRL_STAT= 0x04	--Control & Status
	DP4_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP8_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP8_RESEND 	= 0x08	--Resend (SW Read Only)
	DPc_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP0_CSW = 0x00	--Control and Status Word
	AP4_TAR = 0x04	--Transfer Address	
	AP8	 = 0X08	
	APc_DRW = 0x0C	--Data Read/Write
	AP10_BD0 = 0x10	--Banked Data 0
	AP14_BD1 = 0x14	--Banked Data 1
	AP18_BD2 = 0x18	--Banked Data 2
	AP1c_BD3 = 0x1C	--Banked Data 3
	APf8_ROM = 0xF8	--Debug ROM Address
	APfc_IDR = 0xFC	--Identification Register
	
	DWT_PCSR   = 0xe000101c
end

function EnterDebugProgram(void)

local i
local id = {}

print("lua EnterDebugProgram(0)")
pg_reset_pin(1)
delayms(30)
pg_reset_pin(0)

for i=0,100,1 do
	id = {pg_swd("JTAG2SWD")}
	print_hex(id[1])
	if (id[1] > 0) then
		break
	end
end
delayms(20)

--LINERESET
pg_swd("RDP", DP0_IDCODE) --0x6ba02477
pg_swd("RDP", DP0_IDCODE) --0x6ba02477
pg_swd("WDP", DP8_SELECT, 0x02000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0x00000040
pg_swd("WDP", DP4_CTRL_STAT, 0x50000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000040
pg_swd("WDP", DP4_CTRL_STAT, 0x50000f00)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP0_ABORT, 0x0000001e)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x02000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WDP", DP8_SELECT, 0x020000f0)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x24770011
pg_swd("WDP", DP8_SELECT, 0x02000000)
pg_swd("RDP", DPc_RDBUFF) --0x24770011
pg_swd("WAP", AP0_CSW, 0x23000060)
pg_swd("RDP", DPc_RDBUFF) --0x24770011
pg_swd("RAP", AP0_CSW) --0x24770011
pg_swd("RDP", DPc_RDBUFF) --0x23000060
pg_swd("WAP", AP0_CSW, 0x23000061)
pg_swd("RDP", DPc_RDBUFF) --0x23000060
pg_swd("RAP", AP0_CSW) --0x23000060
pg_swd("RDP", DPc_RDBUFF) --0x23000061
pg_swd("WAP", AP0_CSW, 0x23000052)
pg_swd("RDP", DPc_RDBUFF) --0x23000061
pg_swd("WDP", DP8_SELECT, 0x02000000)
pg_swd("RDP", DPc_RDBUFF) --0x23000061
pg_swd("WAP", AP0_CSW, 0x23000052)
pg_swd("RDP", DPc_RDBUFF) --0x23000061
pg_swd("WDP", DP8_SELECT, 0x020000f0)
pg_swd("RDP", DPc_RDBUFF) --0x23000061
pg_swd("RAP", AP8) --0x23000061
pg_swd("RDP", DPc_RDBUFF) --0xe00ff003
pg_swd("WDP", DP8_SELECT, 0x02000000)
pg_swd("RDP", DPc_RDBUFF) --0xe00ff003
pg_swd("WAP", AP0_CSW, 0x23000052)
pg_swd("RDP", DPc_RDBUFF) --0xe00ff003
pg_swd("WAP", AP4_TAR, 0xe00ffff0) --0xe00ffff0
pg_swd("RDP", DPc_RDBUFF) --0xe00ff003
pg_swd("RAP", APc_DRW) --0xe00ff003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000010
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe00fffd0) --0xe00fffd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000041
pg_swd("RAP", APc_DRW) --0x0000002b
pg_swd("RDP", DPc_RDBUFF) --0x00000030
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe00ff000) --0xe00ff000
pg_swd("RAP", APc_DRW) --0x00000030
pg_swd("RDP", DPc_RDBUFF) --0xfff81003
pg_swd("WAP", AP4_TAR, 0xe0080ff0) --0xe0080ff0
pg_swd("RDP", DPc_RDBUFF) --0xfff81003
pg_swd("RAP", APc_DRW) --0xfff81003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0080fd0) --0xe0080fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000006
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000005b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0080fc8) --0xe0080fc8
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00040800
pg_swd("WAP", AP4_TAR, 0xe00ff004) --0xe00ff004
pg_swd("RAP", APc_DRW) --0x00040800
pg_swd("RDP", DPc_RDBUFF) --0xfff8d002
pg_swd("WAP", AP4_TAR, 0xe00ff008) --0xe00ff008
pg_swd("RAP", APc_DRW) --0xfff8d002
pg_swd("RDP", DPc_RDBUFF) --0xfff8e002
pg_swd("WAP", AP4_TAR, 0xe00ff00c) --0xe00ff00c
pg_swd("RAP", APc_DRW) --0xfff8e002
pg_swd("RDP", DPc_RDBUFF) --0xfff8f003
pg_swd("WAP", AP4_TAR, 0xe008eff0) --0xe008eff0
pg_swd("RDP", DPc_RDBUFF) --0xfff8f003
pg_swd("RAP", APc_DRW) --0xfff8f003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe008efd0) --0xe008efd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000023
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000003b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe00ff010) --0xe00ff010
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff80003
pg_swd("WAP", AP4_TAR, 0xe007fff0) --0xe007fff0
pg_swd("RDP", DPc_RDBUFF) --0xfff80003
pg_swd("RAP", APc_DRW) --0xfff80003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000010
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007ffd0) --0xe007ffd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000041
pg_swd("RAP", APc_DRW) --0x0000002b
pg_swd("RDP", DPc_RDBUFF) --0x00000030
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007f000) --0xe007f000
pg_swd("RAP", APc_DRW) --0x00000030
pg_swd("RDP", DPc_RDBUFF) --0xfff8f003
pg_swd("WAP", AP4_TAR, 0xe000eff0) --0xe000eff0
pg_swd("RDP", DPc_RDBUFF) --0xfff8f003
pg_swd("RAP", APc_DRW) --0xfff8f003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe000efd0) --0xe000efd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x0000000c
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe007f004) --0xe007f004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff82003
pg_swd("WAP", AP4_TAR, 0xe0001ff0) --0xe0001ff0
pg_swd("RDP", DPc_RDBUFF) --0xfff82003
pg_swd("RAP", APc_DRW) --0xfff82003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0001fd0) --0xe0001fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000002
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000003b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007f008) --0xe007f008
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff83003
pg_swd("WAP", AP4_TAR, 0xe0002ff0) --0xe0002ff0
pg_swd("RDP", DPc_RDBUFF) --0xfff83003
pg_swd("RAP", APc_DRW) --0xfff83003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0002fd0) --0xe0002fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000003
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000002b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007f00c) --0xe007f00c
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfff81003
pg_swd("WAP", AP4_TAR, 0xe0000ff0) --0xe0000ff0
pg_swd("RDP", DPc_RDBUFF) --0xfff81003
pg_swd("RAP", APc_DRW) --0xfff81003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x000000e0
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0000fd0) --0xe0000fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000001
pg_swd("RAP", APc_DRW) --0x000000b0
pg_swd("RAP", APc_DRW) --0x0000003b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007f010) --0xe007f010
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0xfffc3003
pg_swd("WAP", AP4_TAR, 0xe0042ff0) --0xe0042ff0
pg_swd("RDP", DPc_RDBUFF) --0xfffc3003
pg_swd("RAP", APc_DRW) --0xfffc3003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0042fd0) --0xe0042fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000006
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000005b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0042fc8) --0xe0042fc8
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00040800
pg_swd("WAP", AP4_TAR, 0xe007f014) --0xe007f014
pg_swd("RAP", APc_DRW) --0x00040800
pg_swd("RDP", DPc_RDBUFF) --0xfffc2003
pg_swd("WAP", AP4_TAR, 0xe0041ff0) --0xe0041ff0
pg_swd("RDP", DPc_RDBUFF) --0xfffc2003
pg_swd("RAP", APc_DRW) --0xfffc2003
pg_swd("RAP", APc_DRW) --0x0000000d
pg_swd("RAP", APc_DRW) --0x00000090
pg_swd("RAP", APc_DRW) --0x00000005
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe0041fd0) --0xe0041fd0
pg_swd("RDP", DPc_RDBUFF) --0x000000b1
pg_swd("RAP", APc_DRW) --0x000000b1
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RAP", APc_DRW) --0x00000025
pg_swd("RAP", APc_DRW) --0x000000b9
pg_swd("RAP", APc_DRW) --0x0000000b
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe007f018) --0xe007f018
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe00ff014) --0xe00ff014
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000ed00) --NVIC_CPUID
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x410fc241
pg_swd("WAP", AP4_TAR, 0xe000ef40) --0xe000ef40
pg_swd("RAP", APc_DRW) --0x410fc241
pg_swd("RDP", DPc_RDBUFF) --0x10110021
pg_swd("WAP", AP4_TAR, 0xe000ef44) --0xe000ef44
pg_swd("RAP", APc_DRW) --0x10110021
pg_swd("RDP", DPc_RDBUFF) --0x11000011
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x11000011
pg_swd("RDP", DPc_RDBUFF) --0x03090000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0001)
pg_swd("RDP", DPc_RDBUFF) --0x03090000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RDP", DPc_RDBUFF) --0x03090000
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x03090000
pg_swd("RDP", DPc_RDBUFF) --0x01030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("WAP", APc_DRW, 0xa05f0003)
pg_swd("RDP", DPc_RDBUFF) --0x01030003
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("RAP", APc_DRW) --0x01030003
pg_swd("RDP", DPc_RDBUFF) --0x01000000
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("RAP", APc_DRW) --0x01000000
pg_swd("RDP", DPc_RDBUFF) --0x00000260
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("RAP", APc_DRW) --0x00000260
pg_swd("RDP", DPc_RDBUFF) --0x40000000
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("WAP", APc_DRW, 0x0000001f)
pg_swd("RDP", DPc_RDBUFF) --0x40000000
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("RAP", APc_DRW) --0x40000000
pg_swd("RDP", DPc_RDBUFF) --0x0000000f
pg_swd("WAP", AP4_TAR, 0xe0001024) --0xe0001024
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x0000000f
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x0000000f
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("RAP", APc_DRW) --0x0000000f
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000080
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000080
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x00000080
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("RAP", APc_DRW) --0x00000080
pg_swd("RDP", DPc_RDBUFF) --0x00000300
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000300
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("RAP", APc_DRW) --0x00000300
pg_swd("RDP", DPc_RDBUFF) --0x00000200
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000200
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x00000200
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("RAP", APc_DRW) --0x00000200
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("WAP", APc_DRW, 0x00000100)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("WAP", APc_DRW, 0x00000080)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0002000) --0xe0002000
pg_swd("WAP", APc_DRW, 0x00000002)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001028) --0xe0001028
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001038) --0xe0001038
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001048) --0xe0001048
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe0001058) --0xe0001058
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000e004) --NVIC_ICT
pg_swd("RAP", APc_DRW) --0x00000000
pg_swd("RDP", DPc_RDBUFF) --0x00000004
pg_swd("WAP", AP4_TAR, 0xe0001000) --0xe0001000
pg_swd("RDP", DPc_RDBUFF) --0x00000004
pg_swd("WAP", APc_DRW, 0x00000001)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000004
pg_swd("RDP", DP4_CTRL_STAT) --0xf0000f40
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x00000001)
pg_swd("RDP", DPc_RDBUFF) --0x00000004
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000004
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000ed0c) --NVIC_AIRCR
pg_swd("WAP", APc_DRW, 0x05fa0001)
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x02030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x02030003
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00000001
pg_swd("WAP", AP4_TAR, 0xe000edf0) --DBG_HCSR
pg_swd("RAP", APc_DRW) --0x00000001
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x00000000)
pg_swd("RDP", DPc_RDBUFF) --0x00030003
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("RAP", APc_DRW) --0x00030003
pg_swd("RDP", DPc_RDBUFF) --0x00000000
pg_swd("WAP", AP4_TAR, 0xe000edfc) --DBG_EMCR
pg_swd("WAP", APc_DRW, 0x01000000)
pg_swd("RDP", DPc_RDBUFF) --0x00000000
delayms(15)

end

SWD_RegDefine()
---------------------------结束-----------------------------------
