beep()
str = i2c_bus("recive", 2)
print_hex(str)

local byte0 = tonumber(string.byte(str,1,1))
local byte1 = tonumber(string.byte(str,2,2))

w = byte0 * 256 + byte1
print(w)



