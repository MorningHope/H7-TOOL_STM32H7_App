//---------------------------------------------------------------------------

#ifndef UnitDsoH
#define UnitDsoH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TFormDso : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
	__fastcall TFormDso(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormDso *FormDso;
//---------------------------------------------------------------------------
#endif
