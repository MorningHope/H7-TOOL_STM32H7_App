/*
*********************************************************************************************************
*
*	ģ������ : hexתbin�ļ�
*	�ļ����� : hex2bin.h
*
*********************************************************************************************************
*/

#ifndef __HEX2BIN_H
#define __HEX2BIN_H

int MyHexToBin(char *_HexBuf, int _HexBufSize, char *_BinBuf, int _BinBufSize,
	unsigned char _InitValue, unsigned int *_StartAddress);

#endif

/***************************** ���������� www.armfly.com (END OF FILE) *********************************/
