
print(12) 
