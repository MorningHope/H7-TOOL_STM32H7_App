print("test beep1")
beep()
delayms(200)

print("test beep2")
beep()
delayus(200000)

beep()
print("test beep2")
