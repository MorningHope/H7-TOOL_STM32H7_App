--дģ����У׼����
function write_calib(void)
  write_regfloat(0xC000, 32538.400) --CH1[0].x1
  write_regfloat(0xC002, 0.000) --CH1[0].y1
  write_regfloat(0xC004, 53038.801) --CH1[0].x2
  write_regfloat(0xC006, 9.002) --CH1[0].y2

  write_regfloat(0xC008, 32528.000) --CH1[1].x1
  write_regfloat(0xC00A, 0.000) --CH1[1].y1
  write_regfloat(0xC00C, 59892.000) --CH1[1].x2
  write_regfloat(0xC00E, 6.000) --CH1[1].y2

  write_regfloat(0xC010, 32505.000) --CH1[2].x1
  write_regfloat(0xC012, 0.000) --CH1[2].y1
  write_regfloat(0xC014, 60035.000) --CH1[2].x2
  write_regfloat(0xC016, 3.000) --CH1[2].y2

  write_regfloat(0xC018, 32463.199) --CH1[3].x1
  write_regfloat(0xC01A, 0.000) --CH1[3].y1
  write_regfloat(0xC01C, 59987.801) --CH1[3].x2
  write_regfloat(0xC01E, 1.500) --CH1[3].y2

  write_regfloat(0xC020, 32383.801) --CH1[4].x1
  write_regfloat(0xC022, 0.000) --CH1[4].y1
  write_regfloat(0xC024, 60013.000) --CH1[4].x2
  write_regfloat(0xC026, 0.750) --CH1[4].y2

  write_regfloat(0xC028, 32238.400) --CH1[5].x1
  write_regfloat(0xC02A, 0.000) --CH1[5].y1
  write_regfloat(0xC02C, 59853.199) --CH1[5].x2
  write_regfloat(0xC02E, 0.375) --CH1[5].y2

  write_regfloat(0xC030, 31942.199) --CH1[6].x1
  write_regfloat(0xC032, 0.000) --CH1[6].y1
  write_regfloat(0xC034, 56841.602) --CH1[6].x2
  write_regfloat(0xC036, 0.169) --CH1[6].y2

  write_regfloat(0xC038, 31387.600) --CH1[7].x1
  write_regfloat(0xC03A, 0.000) --CH1[7].y1
  write_regfloat(0xC03C, 57851.199) --CH1[7].x2
  write_regfloat(0xC03E, 0.090) --CH1[7].y2

  write_regfloat(0xC040, 32641.600) --CH2[0].x1
  write_regfloat(0xC042, 0.000) --CH2[0].y1
  write_regfloat(0xC044, 53181.398) --CH2[0].x2
  write_regfloat(0xC046, 9.002) --CH2[0].y2

  write_regfloat(0xC048, 32655.600) --CH2[1].x1
  write_regfloat(0xC04A, 0.000) --CH2[1].y1
  write_regfloat(0xC04C, 60094.000) --CH2[1].x2
  write_regfloat(0xC04E, 6.000) --CH2[1].y2

  write_regfloat(0xC050, 32684.199) --CH2[2].x1
  write_regfloat(0xC052, 0.000) --CH2[2].y1
  write_regfloat(0xC054, 60181.000) --CH2[2].x2
  write_regfloat(0xC056, 3.000) --CH2[2].y2

  write_regfloat(0xC058, 32742.000) --CH2[3].x1
  write_regfloat(0xC05A, 0.000) --CH2[3].y1
  write_regfloat(0xC05C, 60362.398) --CH2[3].x2
  write_regfloat(0xC05E, 1.500) --CH2[3].y2

  write_regfloat(0xC060, 32857.000) --CH2[4].x1
  write_regfloat(0xC062, 0.000) --CH2[4].y1
  write_regfloat(0xC064, 60625.801) --CH2[4].x2
  write_regfloat(0xC066, 0.750) --CH2[4].y2

  write_regfloat(0xC068, 33086.000) --CH2[5].x1
  write_regfloat(0xC06A, 0.000) --CH2[5].y1
  write_regfloat(0xC06C, 60874.398) --CH2[5].x2
  write_regfloat(0xC06E, 0.375) --CH2[5].y2

  write_regfloat(0xC070, 33543.000) --CH2[6].x1
  write_regfloat(0xC072, 0.000) --CH2[6].y1
  write_regfloat(0xC074, 58705.801) --CH2[6].x2
  write_regfloat(0xC076, 0.169) --CH2[6].y2

  write_regfloat(0xC078, 34456.000) --CH2[7].x1
  write_regfloat(0xC07A, 0.000) --CH2[7].y1
  write_regfloat(0xC07C, 61142.000) --CH2[7].x2
  write_regfloat(0xC07E, 0.090) --CH2[7].y2

  write_regfloat(0xC080, 2911.400) --LoadVolt.x1
  write_regfloat(0xC082, 1.594) --LoadVolt.y1
  write_regfloat(0xC084, 8092.000) --LoadVolt.x2
  write_regfloat(0xC086, 4.418) --LoadVolt.y2

  write_regfloat(0xC088, 949.400) --LoadCurr[0].x1
  write_regfloat(0xC08A, 0.000) --LoadCurr[0].y1
  write_regfloat(0xC08C, 16409.000) --LoadCurr[0].x2
  write_regfloat(0xC08E, 29.742) --LoadCurr[0].y2
  write_regfloat(0xC090, 26924.000) --LoadCurr[0].x3
  write_regfloat(0xC092, 49.189) --LoadCurr[0].y3
  write_regfloat(0xC094, 49071.801) --LoadCurr[0].x4
  write_regfloat(0xC096, 89.834) --LoadCurr[0].y4

  write_regfloat(0xC098, 126.000) --LoadCurr[1].x1
  write_regfloat(0xC09A, 0.000) --LoadCurr[1].y1
  write_regfloat(0xC09C, 7822.800) --LoadCurr[1].x2
  write_regfloat(0xC09E, 142.333) --LoadCurr[1].y2
  write_regfloat(0xC0A0, 15455.000) --LoadCurr[1].x3
  write_regfloat(0xC0A2, 283.886) --LoadCurr[1].y3
  write_regfloat(0xC0A4, 20427.000) --LoadCurr[1].x4
  write_regfloat(0xC0A6, 376.089) --LoadCurr[1].y4

  write_regfloat(0xC0A8, 16550.400) --TVCCVolt.x1
  write_regfloat(0xC0AA, 1.594) --TVCCVolt.y1
  write_regfloat(0xC0AC, 45857.398) --TVCCVolt.x2
  write_regfloat(0xC0AE, 4.418) --TVCCVolt.y2

  write_regfloat(0xC0B0, 455.200) --TVCCCurr.x1
  write_regfloat(0xC0B2, 0.000) --TVCCCurr.y1
  write_regfloat(0xC0B4, 21524.199) --TVCCCurr.x2
  write_regfloat(0xC0B6, 142.333) --TVCCCurr.y2
  write_regfloat(0xC0B8, 43019.801) --TVCCCurr.x3
  write_regfloat(0xC0BA, 283.886) --TVCCCurr.y3
  write_regfloat(0xC0BC, 57060.801) --TVCCCurr.x4
  write_regfloat(0xC0BE, 376.089) --TVCCCurr.y4

  write_regfloat(0xC0C0, 127.000) --TVCCSet.x1
  write_regfloat(0xC0C2, 1.260) --TVCCSet.y1
  write_regfloat(0xC0C4, 36.000) --TVCCSet.x2
  write_regfloat(0xC0C6, 4.440) --TVCCSet.y2

  write_reg16(0xC0C8, 500) --Dac10V.x1
  write_reg16(0xC0C9, -9152) --Dac10V.y1 (mV)
  write_reg16(0xC0CA, 1500) --Dac10V.x2
  write_reg16(0xC0CB, -3216) --Dac10V.y2 (mV)
  write_reg16(0xC0CC, 2500) --Dac10V.x3
  write_reg16(0xC0CD, 2719) --Dac10V.y3 (mV)
  write_reg16(0xC0CE, 3500) --Dac10V.x4
  write_reg16(0xC0CF, 8656) --Dac10V.y4 (mV)

  write_reg16(0xC0D0, 500) --Dac20mA.x1
  write_reg16(0xC0D1, 2589) --Dac20mA.y1 (uA)
  write_reg16(0xC0D2, 1500) --Dac20mA.x2
  write_reg16(0xC0D3, 7730) --Dac20mA.y2 (uA)
  write_reg16(0xC0D4, 2500) --Dac20mA.x3
  write_reg16(0xC0D5, 12871) --Dac20mA.y3 (uA)
  write_reg16(0xC0D6, 3500) --Dac20mA.x4
  write_reg16(0xC0D7, 18010) --Dac20mA.y4 (uA)

  write_regfloat(0xC0D8, 71.400) --NtcRes.x1
  write_regfloat(0xC0DA, 0.000) --NtcRes.y1
  write_regfloat(0xC0DC, 285.200) --NtcRes.x2
  write_regfloat(0xC0DE, 0.022) --NtcRes.y2
  write_regfloat(0xC0E0, 43318.801) --NtcRes.x3
  write_regfloat(0xC0E2, 9.973) --NtcRes.y3
  write_regfloat(0xC0E4, 62301.602) --NtcRes.x4
  write_regfloat(0xC0E6, 99.958) --NtcRes.y4

  save_param()	--���������eeprom
end

write_calib()
beep()
print("д��ģ����У׼�����ɹ�")
