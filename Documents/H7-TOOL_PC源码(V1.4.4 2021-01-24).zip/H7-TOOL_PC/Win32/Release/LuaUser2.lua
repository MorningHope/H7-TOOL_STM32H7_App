print(pg_write32(RAM_ADDRESS, 0x12345678))
InitUnderReset()
ReadDeviceID()

print_hex(RAM_ADDRESS)
