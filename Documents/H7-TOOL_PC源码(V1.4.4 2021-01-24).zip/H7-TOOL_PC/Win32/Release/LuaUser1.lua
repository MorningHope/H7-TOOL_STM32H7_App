beep()

ff = tonumber("+5.69077E-02")
print(ff)


ff = tonumber("+1.799989999E+05")
print(ff)

ff = tonumber("-6.00728E-02")
print(ff)
